import { M as t, b as s, d as i, f as r, i as c, m as n, c as x, r as d, e as m } from "./libaifw-Dv6TWIU-.js";
export {
  t as MatchedPIISpan,
  s as deinit,
  i as detectLanguage,
  r as getPiiSpans,
  c as init,
  n as maskText,
  x as maskTextBatch,
  d as restoreText,
  m as restoreTextBatch
};
